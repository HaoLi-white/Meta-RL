
"""
2023-03-23:完成SIR_DQN环境编写
"""
from parameter import *
import math
from gym.utils import seeding
from typing import Any, Dict, List, Tuple

class SIR:
    def __init__(self):
        self.state_dim = 10  
        self.action_dim = 3  

    
    def reset(self):
        return self.origin_state

    def get_all_task_idx(self) -> List[int]:
        return list(range(len(self.tasks)))

    def reset_task(self, idx: int) -> None:

        return reward


    
    def step1(self, action_idx):
        next_state = self.origin_state  
        reward = 0
        done = False
        b0 = action_idx[0][0]  
        b1 = action_idx[0][1]  
        b2 = action_idx[0][2]  
        t = self.t  


        return next_state, reward, done

    def step2(self, action_idx):
        next_state = self.origin_state  
        reward = 0
        done = False


        return next_state, reward, done