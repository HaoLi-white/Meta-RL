from typing import Dict, List, Tuple

import numpy as np
import torch
from gym.envs.mujoco.half_cheetah import HalfCheetahEnv

from algorithm.sac import SAC





class Sampler:
    def __init__(
        self,
        env: HalfCheetahEnv,
        env1: HalfCheetahEnv,
        env2: HalfCheetahEnv,
        env3: HalfCheetahEnv,
        env4: HalfCheetahEnv,
        env5: HalfCheetahEnv,
        agent: SAC,
        max_step: int,
        device: torch.device,
    ) -> None:

        self.env = env
        self.env1 = env1
        self.env2 = env2
        self.env3 = env3
        self.env4 = env4
        self.env5 = env5
        self.agent = agent
        self.max_step = max_step
        self.device = device
        self.num_agents = 2

    def obtain_samples_action(
            self,
            max_samples: int,
            update_posterior: bool,
            task:int,
            accum_context: bool = True,
    ) -> Tuple[List[Dict[str, np.ndarray]], int]:
        
        trajs = []
        cur_samples = 0
        reward = 0
        while cur_samples < max_samples:
            if task==1:
                traj, reward = self.rollout_action1(accum_context=accum_context)
                trajs.append(traj)
                cur_samples += len(traj["cur_obs"])
                self.agent.encoder.sample_z()
            if task==2:
                traj, reward = self.rollout_action2(accum_context=accum_context)
                trajs.append(traj)
                cur_samples += len(traj["cur_obs"])
                self.agent.encoder.sample_z()
            if task==3:
                traj, reward = self.rollout_action3(accum_context=accum_context)
                trajs.append(traj)
                cur_samples += len(traj["cur_obs"])
                self.agent.encoder.sample_z()
            if task==4:
                traj, reward = self.rollout_action4(accum_context=accum_context)
                trajs.append(traj)
                cur_samples += len(traj["cur_obs"])
                self.agent.encoder.sample_z()
            if task==5:
                traj, reward = self.rollout_action5(accum_context=accum_context)
                trajs.append(traj)
                cur_samples += len(traj["cur_obs"])
                self.agent.encoder.sample_z()
            if update_posterior:
                break
        return trajs, cur_samples, reward



    def obtain_train_samples(
        self,
        max_samples: int,
        update_posterior: bool,
        accum_context: bool = True,
    ) -> Tuple[List[Dict[str, np.ndarray]], int]:
        
        trajs = []
        cur_samples = 0
        reward=0
        while cur_samples < max_samples:
            traj,reward = self.rollout_train(accum_context=accum_context)
            trajs.append(traj)
            cur_samples += len(traj["cur_obs"])
            self.agent.encoder.sample_z()

            if update_posterior:
                break
        return trajs, cur_samples,reward

    def obtain_samples1(
        self,
        max_samples: int,
        update_posterior: bool,
        accum_context: bool = True,
    ) -> Tuple[List[Dict[str, np.ndarray]], int]:
        
        trajs = []
        cur_samples = 0
        reward=0
        while cur_samples < max_samples:
            traj,reward = self.rollout_test1(accum_context=accum_context)
            trajs.append(traj)
            cur_samples += len(traj["cur_obs"])
            self.agent.encoder.sample_z()

            if update_posterior:
                break
        return trajs, cur_samples,reward


    def obtain_samples2(
        self,
        max_samples: int,
        update_posterior: bool,
        accum_context: bool = True,
    ) -> Tuple[List[Dict[str, np.ndarray]], int]:
        
        trajs = []
        cur_samples = 0

        while cur_samples < max_samples:
            traj,reward = self.rollout_test2(accum_context=accum_context)
            trajs.append(traj)
            cur_samples += len(traj["cur_obs"])
            self.agent.encoder.sample_z()

            if update_posterior:
                break
        return trajs, cur_samples,reward

    def obtain_samples3(
        self,
        max_samples: int,
        update_posterior: bool,
        accum_context: bool = True,
    ) -> Tuple[List[Dict[str, np.ndarray]], int]:
        
        trajs = []
        cur_samples = 0

        while cur_samples < max_samples:
            traj,reward = self.rollout_test3(accum_context=accum_context)
            trajs.append(traj)
            cur_samples += len(traj["cur_obs"])
            self.agent.encoder.sample_z()

            if update_posterior:
                break
        return trajs, cur_samples,reward

    def obtain_samples4(
        self,
        max_samples: int,
        update_posterior: bool,
        accum_context: bool = True,
    ) -> Tuple[List[Dict[str, np.ndarray]], int]:
        
        trajs = []
        cur_samples = 0

        while cur_samples < max_samples:
            traj,reward = self.rollout_test4(accum_context=accum_context)
            trajs.append(traj)
            cur_samples += len(traj["cur_obs"])
            self.agent.encoder.sample_z()

            if update_posterior:
                break
        return trajs, cur_samples,reward

    def obtain_samples5(
            self,
            max_samples: int,
            update_posterior: bool,
            accum_context: bool = True,
    ) -> Tuple[List[Dict[str, np.ndarray]], int]:
        
        trajs = []
        cur_samples = 0

        while cur_samples < max_samples:
            traj, reward = self.rollout_test5(accum_context=accum_context)
            trajs.append(traj)
            cur_samples += len(traj["cur_obs"])
            self.agent.encoder.sample_z()

            if update_posterior:
                break
        return trajs, cur_samples, reward

    def rollout_train(self, accum_context: bool = True) -> Dict[str, np.ndarray]:
        
        _cur_obs = []
        _actions = []
        _rewards = []
        _next_obs = []
        _dones = []
        _infos = []
        obs = self.env.reset()
        score = [0 for _ in range(self.num_agents)]
        done = False
        cur_step = 0
        
        while not done :
            get_action = []
            for i in range(self.num_agents):
                action = self.agent.get_action(obs)
                get_action.append(action)
            

            next_obs, reward, done= self.env.step1(get_action)
            next_obs1, reward1, done1 = self.env.step2(get_action)
            rewards = [reward, reward1]
            
            if accum_context:
                self.update_context(obs=obs, action=get_action[0], reward=np.array([reward]))
                self.update_context(obs=obs, action=get_action[1], reward=np.array([reward1]))
            _cur_obs.append(obs)
            _cur_obs.append(obs)
            _actions.append(get_action[0])
            _actions.append(get_action[1])
            _rewards.append(reward)
            _rewards.append(reward1)
            _next_obs.append(next_obs)
            _next_obs.append(next_obs1)
            _dones.append(done)
            _dones.append(done1)
            
            
            for i in range(self.num_agents):
                score[i] += rewards[i]

            cur_step += 1
            if reward > reward1:
                obs = next_obs
            else:
                obs = next_obs1
        if max(score)>-10:
            for i in range(self.num_agents):
                score[i] -= 8
        scores = max(score)
        
        
        return dict(
            cur_obs=np.array(_cur_obs),
            actions=np.array(_actions),
            rewards=np.array(_rewards).reshape(-1, 1),
            next_obs=np.array(_next_obs),
            dones=np.array(_dones).reshape(-1, 1),
            
        ),scores

    def rollout_test1(self, accum_context: bool = True) -> Dict[str, np.ndarray]:
        
        _cur_obs = []
        _actions = []
        _rewards = []
        _next_obs = []
        _dones = []
        _infos = []
        obs = self.env.reset()
        score = [0 for _ in range(self.num_agents)]
        done = False
        cur_step = 0
        
        while not done :
            get_action = []
            for i in range(self.num_agents):
                action = self.agent.get_action(obs)
                get_action.append(action)
            

            next_obs, reward, done= self.env1.step1(get_action)
            next_obs1, reward1, done1 = self.env1.step2(get_action)
            rewards = [reward, reward1]
            
            if accum_context:
                self.update_context(obs=obs, action=get_action[0], reward=np.array([reward]))
                self.update_context(obs=obs, action=get_action[1], reward=np.array([reward1]))
            _cur_obs.append(obs)
            _cur_obs.append(obs)
            _actions.append(get_action[0])
            _actions.append(get_action[1])
            _rewards.append(reward)
            _rewards.append(reward1)
            _next_obs.append(next_obs)
            _next_obs.append(next_obs1)
            _dones.append(done)
            _dones.append(done1)
            
            
            for i in range(self.num_agents):
                score[i] += rewards[i]

            cur_step += 1
            if reward > reward1:
                obs = next_obs
            else:
                obs = next_obs1
        if max(score)>-10:
            for i in range(self.num_agents):
                score[i] -= 8
        scores = max(score)
        
        
        return dict(
            cur_obs=np.array(_cur_obs),
            actions=np.array(_actions),
            rewards=np.array(_rewards).reshape(-1, 1),
            next_obs=np.array(_next_obs),
            dones=np.array(_dones).reshape(-1, 1),
            
        ),scores


    def rollout_test2(self, accum_context: bool = True) -> Dict[str, np.ndarray]:
        
        _cur_obs = []
        _actions = []
        _rewards = []
        _next_obs = []
        _dones = []
        _infos = []
        obs = self.env.reset()
        score = [0 for _ in range(self.num_agents)]
        done = False
        cur_step = 0
        
        while not done:
            get_action = []
            for i in range(self.num_agents):
                action = self.agent.get_action(obs)
                get_action.append(action)
            

            next_obs, reward, done= self.env2.step1(get_action)
            next_obs1, reward1, done1 = self.env2.step2(get_action)
            rewards = [reward, reward1]
            
            if accum_context:
                self.update_context(obs=obs, action=get_action[0], reward=np.array([reward]))
                self.update_context(obs=obs, action=get_action[1], reward=np.array([reward1]))
            _cur_obs.append(obs)
            _cur_obs.append(obs)
            _actions.append(get_action[0])
            _actions.append(get_action[1])
            _rewards.append(reward)
            _rewards.append(reward1)
            _next_obs.append(next_obs)
            _next_obs.append(next_obs1)
            _dones.append(done)
            _dones.append(done1)
            
            
            for i in range(self.num_agents):
                score[i] += rewards[i]

            cur_step += 1
            if reward > reward1:
                obs = next_obs
            else:
                obs = next_obs1
        if max(score) > -10:
            for i in range(self.num_agents):
                score[i] -= 8
        scores = max(score)
        
        
        return dict(
            cur_obs=np.array(_cur_obs),
            actions=np.array(_actions),
            rewards=np.array(_rewards).reshape(-1, 1),
            next_obs=np.array(_next_obs),
            dones=np.array(_dones).reshape(-1, 1),
            
        ), scores

    def rollout_test3(self, accum_context: bool = True) -> Dict[str, np.ndarray]:
        
        _cur_obs = []
        _actions = []
        _rewards = []
        _next_obs = []
        _dones = []
        _infos = []
        obs = self.env.reset()
        score = [0 for _ in range(self.num_agents)]
        done = False
        cur_step = 0
        
        while not done:
            get_action = []
            for i in range(self.num_agents):
                action = self.agent.get_action(obs)
                get_action.append(action)
            

            next_obs, reward, done= self.env3.step1(get_action)
            next_obs1, reward1, done1 = self.env3.step2(get_action)
            rewards = [reward, reward1]
            
            if accum_context:
                self.update_context(obs=obs, action=get_action[0], reward=np.array([reward]))
                self.update_context(obs=obs, action=get_action[1], reward=np.array([reward1]))
            _cur_obs.append(obs)
            _cur_obs.append(obs)
            _actions.append(get_action[0])
            _actions.append(get_action[1])
            _rewards.append(reward)
            _rewards.append(reward1)
            _next_obs.append(next_obs)
            _next_obs.append(next_obs1)
            _dones.append(done)
            _dones.append(done1)
            
            
            for i in range(self.num_agents):
                score[i] += rewards[i]

            cur_step += 1
            if reward > reward1:
                obs = next_obs
            else:
                obs = next_obs1
        if max(score) > -10:
            for i in range(self.num_agents):
                score[i] -= 8
        scores = max(score)
        
        
        return dict(
            cur_obs=np.array(_cur_obs),
            actions=np.array(_actions),
            rewards=np.array(_rewards).reshape(-1, 1),
            next_obs=np.array(_next_obs),
            dones=np.array(_dones).reshape(-1, 1),
            
        ), scores

    def rollout_test4(self, accum_context: bool = True) -> Dict[str, np.ndarray]:
        
        _cur_obs = []
        _actions = []
        _rewards = []
        _next_obs = []
        _dones = []
        _infos = []
        obs = self.env.reset()
        score = [0 for _ in range(self.num_agents)]
        done = False
        cur_step = 0
        
        while not done:
            get_action = []
            for i in range(self.num_agents):
                action = self.agent.get_action(obs)
                get_action.append(action)
            

            next_obs, reward, done= self.env5.step1(get_action)
            next_obs1, reward1, done1 = self.env5.step2(get_action)
            rewards = [reward, reward1]
            
            if accum_context:
                self.update_context(obs=obs, action=get_action[0], reward=np.array([reward]))
                self.update_context(obs=obs, action=get_action[1], reward=np.array([reward1]))
            _cur_obs.append(obs)
            _cur_obs.append(obs)
            _actions.append(get_action[0])
            _actions.append(get_action[1])
            _rewards.append(reward)
            _rewards.append(reward1)
            _next_obs.append(next_obs)
            _next_obs.append(next_obs1)
            _dones.append(done)
            _dones.append(done1)
            
            
            for i in range(self.num_agents):
                score[i] += rewards[i]

            cur_step += 1
            if reward > reward1:
                obs = next_obs
            else:
                obs = next_obs1
        if max(score) > -10:
            for i in range(self.num_agents):
                score[i] -= 8
        scores = max(score)
        
        
        return dict(
            cur_obs=np.array(_cur_obs),
            actions=np.array(_actions),
            rewards=np.array(_rewards).reshape(-1, 1),
            next_obs=np.array(_next_obs),
            dones=np.array(_dones).reshape(-1, 1),
            
        ), scores

    def rollout_test5(self, accum_context: bool = True) -> Dict[str, np.ndarray]:
        
        _cur_obs = []
        _actions = []
        _rewards = []
        _next_obs = []
        _dones = []
        _infos = []
        obs = self.env.reset()
        score = [0 for _ in range(self.num_agents)]
        done = False
        cur_step = 0
        
        while not done:
            get_action = []
            for i in range(self.num_agents):
                action = self.agent.get_action(obs)
                get_action.append(action)
            

            next_obs, reward, done= self.env5.step1(get_action)
            next_obs1, reward1, done1 = self.env5.step2(get_action)
            rewards = [reward, reward1]
            
            if accum_context:
                self.update_context(obs=obs, action=get_action[0], reward=np.array([reward]))
                self.update_context(obs=obs, action=get_action[1], reward=np.array([reward1]))
            _cur_obs.append(obs)
            _cur_obs.append(obs)
            _actions.append(get_action[0])
            _actions.append(get_action[1])
            _rewards.append(reward)
            _rewards.append(reward1)
            _next_obs.append(next_obs)
            _next_obs.append(next_obs1)
            _dones.append(done)
            _dones.append(done1)
            
            
            for i in range(self.num_agents):
                score[i] += rewards[i]

            cur_step += 1
            if reward > reward1:
                obs = next_obs
            else:
                obs = next_obs1
        if max(score) > -10:
            for i in range(self.num_agents):
                score[i] -= 8
        scores = max(score)
        
        
        return dict(
            cur_obs=np.array(_cur_obs),
            actions=np.array(_actions),
            rewards=np.array(_rewards).reshape(-1, 1),
            next_obs=np.array(_next_obs),
            dones=np.array(_dones).reshape(-1, 1),
            
        ), scores
    


    def rollout_action1(self, accum_context: bool = True) -> Dict[str, np.ndarray]:
        
        _cur_obs = []
        _actions = []
        _rewards = []
        _next_obs = []
        _dones = []
        _infos = []
        a=[]
        b=[]
        mulist1 = []
        mulist2 = []
        mulist3 = []
        obs = self.env.reset()
        score = [0 for _ in range(self.num_agents)]
        done = False
        cur_step = 0
        
        while not done :
            get_action = []
            for i in range(self.num_agents):
                action = self.agent.get_action(obs)
                get_action.append(action)
            
            a.append(get_action[0])
            b.append(get_action[1])
            next_obs, reward, done= self.env1.step1(get_action)
            next_obs1, reward1, done1 = self.env1.step2(get_action)
            rewards = [reward, reward1]
            
            if accum_context:
                self.update_context(obs=obs, action=get_action[0], reward=np.array([reward]))
                self.update_context(obs=obs, action=get_action[1], reward=np.array([reward1]))
            _cur_obs.append(obs)
            _cur_obs.append(obs)
            _actions.append(get_action[0])
            _actions.append(get_action[1])
            _rewards.append(reward)
            _rewards.append(reward1)
            _next_obs.append(next_obs)
            _next_obs.append(next_obs1)
            _dones.append(done)
            _dones.append(done1)
            
            
            for i in range(self.num_agents):
                score[i] += rewards[i]

            cur_step += 1
            if reward > reward1:
                obs = next_obs
            else:
                obs = next_obs1
        if max(score)>-10:
            for i in range(self.num_agents):
                score[i] -= 8
        scores = max(score)
        if score[0] > score[1]:
            for i in range(len(a)):
                mulist1.append(a[i][0])
                mulist2.append(a[i][1])
                mulist3.append(a[i][2])
        else:
            for i in range(len(b)):
                mulist1.append(b[i][0])
                mulist2.append(b[i][1])
                mulist3.append(b[i][2])
        print(mulist1)
        print(mulist2)
        print(mulist3)
        print(scores)
        return dict(
            cur_obs=np.array(_cur_obs),
            actions=np.array(_actions),
            rewards=np.array(_rewards).reshape(-1, 1),
            next_obs=np.array(_next_obs),
            dones=np.array(_dones).reshape(-1, 1),
            
        ),scores

    def rollout_action2(self, accum_context: bool = True) -> Dict[str, np.ndarray]:
        
        _cur_obs = []
        _actions = []
        _rewards = []
        _next_obs = []
        _dones = []
        _infos = []
        a=[]
        b=[]
        mulist1 = []
        mulist2 = []
        mulist3 = []
        obs = self.env.reset()
        score = [0 for _ in range(self.num_agents)]
        done = False
        cur_step = 0
        
        while not done :
            get_action = []
            for i in range(self.num_agents):
                action = self.agent.get_action(obs)
                get_action.append(action)
            
            a.append(get_action[0])
            b.append(get_action[1])
            next_obs, reward, done= self.env2.step1(get_action)
            next_obs1, reward1, done1 = self.env2.step2(get_action)
            rewards = [reward, reward1]
            
            if accum_context:
                self.update_context(obs=obs, action=get_action[0], reward=np.array([reward]))
                self.update_context(obs=obs, action=get_action[1], reward=np.array([reward1]))
            _cur_obs.append(obs)
            _cur_obs.append(obs)
            _actions.append(get_action[0])
            _actions.append(get_action[1])
            _rewards.append(reward)
            _rewards.append(reward1)
            _next_obs.append(next_obs)
            _next_obs.append(next_obs1)
            _dones.append(done)
            _dones.append(done1)
            
            
            for i in range(self.num_agents):
                score[i] += rewards[i]

            cur_step += 1
            if reward > reward1:
                obs = next_obs
            else:
                obs = next_obs1
        if max(score)>-10:
            for i in range(self.num_agents):
                score[i] -= 8
        scores = max(score)
        if score[0] > score[1]:
            for i in range(len(a)):
                mulist1.append(a[i][0])
                mulist2.append(a[i][1])
                mulist3.append(a[i][2])
        else:
            for i in range(len(b)):
                mulist1.append(b[i][0])
                mulist2.append(b[i][1])
                mulist3.append(b[i][2])
        print(mulist1)
        print(mulist2)
        print(mulist3)
        print(scores)
        return dict(
            cur_obs=np.array(_cur_obs),
            actions=np.array(_actions),
            rewards=np.array(_rewards).reshape(-1, 1),
            next_obs=np.array(_next_obs),
            dones=np.array(_dones).reshape(-1, 1),
            
        ),scores

    def rollout_action3(self, accum_context: bool = True) -> Dict[str, np.ndarray]:
        
        _cur_obs = []
        _actions = []
        _rewards = []
        _next_obs = []
        _dones = []
        _infos = []
        a=[]
        b=[]
        mulist1 = []
        mulist2 = []
        mulist3 = []
        obs = self.env.reset()
        score = [0 for _ in range(self.num_agents)]
        done = False
        cur_step = 0
        
        while not done :
            get_action = []
            for i in range(self.num_agents):
                action = self.agent.get_action(obs)
                get_action.append(action)
            
            a.append(get_action[0])
            b.append(get_action[1])
            next_obs, reward, done= self.env3.step1(get_action)
            next_obs1, reward1, done1 = self.env3.step2(get_action)
            rewards = [reward, reward1]
            
            if accum_context:
                self.update_context(obs=obs, action=get_action[0], reward=np.array([reward]))
                self.update_context(obs=obs, action=get_action[1], reward=np.array([reward1]))
            _cur_obs.append(obs)
            _cur_obs.append(obs)
            _actions.append(get_action[0])
            _actions.append(get_action[1])
            _rewards.append(reward)
            _rewards.append(reward1)
            _next_obs.append(next_obs)
            _next_obs.append(next_obs1)
            _dones.append(done)
            _dones.append(done1)
            
            
            for i in range(self.num_agents):
                score[i] += rewards[i]

            cur_step += 1
            if reward > reward1:
                obs = next_obs
            else:
                obs = next_obs1
        if max(score)>-10:
            for i in range(self.num_agents):
                score[i] -= 8
        scores = max(score)
        if score[0] > score[1]:
            for i in range(len(a)):
                mulist1.append(a[i][0])
                mulist2.append(a[i][1])
                mulist3.append(a[i][2])
        else:
            for i in range(len(b)):
                mulist1.append(b[i][0])
                mulist2.append(b[i][1])
                mulist3.append(b[i][2])
        print(mulist1)
        print(mulist2)
        print(mulist3)
        print(scores)
        return dict(
            cur_obs=np.array(_cur_obs),
            actions=np.array(_actions),
            rewards=np.array(_rewards).reshape(-1, 1),
            next_obs=np.array(_next_obs),
            dones=np.array(_dones).reshape(-1, 1),
            
        ),scores

    def rollout_action4(self, accum_context: bool = True) -> Dict[str, np.ndarray]:
        
        _cur_obs = []
        _actions = []
        _rewards = []
        _next_obs = []
        _dones = []
        _infos = []
        a=[]
        b=[]
        mulist1 = []
        mulist2 = []
        mulist3 = []
        obs = self.env.reset()
        score = [0 for _ in range(self.num_agents)]
        done = False
        cur_step = 0
        
        while not done :
            get_action = []
            for i in range(self.num_agents):
                action = self.agent.get_action(obs)
                get_action.append(action)
            
            a.append(get_action[0])
            b.append(get_action[1])
            next_obs, reward, done= self.env4.step1(get_action)
            next_obs1, reward1, done1 = self.env4.step2(get_action)
            rewards = [reward, reward1]
            
            if accum_context:
                self.update_context(obs=obs, action=get_action[0], reward=np.array([reward]))
                self.update_context(obs=obs, action=get_action[1], reward=np.array([reward1]))
            _cur_obs.append(obs)
            _cur_obs.append(obs)
            _actions.append(get_action[0])
            _actions.append(get_action[1])
            _rewards.append(reward)
            _rewards.append(reward1)
            _next_obs.append(next_obs)
            _next_obs.append(next_obs1)
            _dones.append(done)
            _dones.append(done1)
            
            
            for i in range(self.num_agents):
                score[i] += rewards[i]

            cur_step += 1
            if reward > reward1:
                obs = next_obs
            else:
                obs = next_obs1
        if max(score)>-10:
            for i in range(self.num_agents):
                score[i] -= 8
        scores = max(score)
        if score[0] > score[1]:
            for i in range(len(a)):
                mulist1.append(a[i][0])
                mulist2.append(a[i][1])
                mulist3.append(a[i][2])
        else:
            for i in range(len(b)):
                mulist1.append(b[i][0])
                mulist2.append(b[i][1])
                mulist3.append(b[i][2])
        print(mulist1)
        print(mulist2)
        print(mulist3)
        print(scores)
        return dict(
            cur_obs=np.array(_cur_obs),
            actions=np.array(_actions),
            rewards=np.array(_rewards).reshape(-1, 1),
            next_obs=np.array(_next_obs),
            dones=np.array(_dones).reshape(-1, 1),
            
        ),scores

    def rollout_action5(self, accum_context: bool = True) -> Dict[str, np.ndarray]:
        
        _cur_obs = []
        _actions = []
        _rewards = []
        _next_obs = []
        _dones = []
        _infos = []
        a=[]
        b=[]
        mulist1 = []
        mulist2 = []
        mulist3 = []
        obs = self.env.reset()
        score = [0 for _ in range(self.num_agents)]
        done = False
        cur_step = 0
        
        while not done :
            get_action = []
            for i in range(self.num_agents):
                action = self.agent.get_action(obs)
                get_action.append(action)
            
            a.append(get_action[0])
            b.append(get_action[1])
            next_obs, reward, done= self.env5.step1(get_action)
            next_obs1, reward1, done1 = self.env5.step2(get_action)
            rewards = [reward, reward1]
            
            if accum_context:
                self.update_context(obs=obs, action=get_action[0], reward=np.array([reward]))
                self.update_context(obs=obs, action=get_action[1], reward=np.array([reward1]))
            _cur_obs.append(obs)
            _cur_obs.append(obs)
            _actions.append(get_action[0])
            _actions.append(get_action[1])
            _rewards.append(reward)
            _rewards.append(reward1)
            _next_obs.append(next_obs)
            _next_obs.append(next_obs1)
            _dones.append(done)
            _dones.append(done1)
            
            
            for i in range(self.num_agents):
                score[i] += rewards[i]

            cur_step += 1
            if reward > reward1:
                obs = next_obs
            else:
                obs = next_obs1
        if max(score)>-10:
            for i in range(self.num_agents):
                score[i] -= 8
        scores = max(score)
        if score[0] > score[1]:
            for i in range(len(a)):
                mulist1.append(a[i][0])
                mulist2.append(a[i][1])
                mulist3.append(a[i][2])
        else:
            for i in range(len(b)):
                mulist1.append(b[i][0])
                mulist2.append(b[i][1])
                mulist3.append(b[i][2])
        print(mulist1)
        print(mulist2)
        print(mulist3)
        print(scores)
        return dict(
            cur_obs=np.array(_cur_obs),
            actions=np.array(_actions),
            rewards=np.array(_rewards).reshape(-1, 1),
            next_obs=np.array(_next_obs),
            dones=np.array(_dones).reshape(-1, 1),
            
        ),scores
    def update_context(self, obs: np.ndarray, action: np.ndarray, reward: np.ndarray) -> None:
        
        obs = np.array(obs)
        action = np.array(action)
        reward = np.array(reward)

        obs = torch.from_numpy(obs).float().to(self.device)
        action = torch.from_numpy(action).float().to(self.device)
        reward = torch.from_numpy(reward).float().to(self.device)
        transition = torch.cat([obs, action, reward], dim=-1).to(self.device)

        if self.agent.encoder.context is None:
            self.agent.encoder.context = transition
        else:
            self.agent.encoder.context = torch.cat([self.agent.encoder.context, transition], dim=-1).to(
                self.device,
            )
