from typing import Tuple

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.distributions import Normal


class MLP(nn.Module):
    def __init__(
        self,
        input_dim: int,
        output_dim: int,
        hidden_dim: int,
        hidden_activation: torch.nn.functional = F.relu,
        init_w: float = 3e-3,
    ) -> None:
        super().__init__()

        self.input_dim = input_dim
        self.output_dim = output_dim
        self.hidden_activation = hidden_activation

        
        self.fc_layers = nn.ModuleList()
        self.hidden_layers = [hidden_dim] * 3
        in_layer = input_dim

        for i, hidden_layer in enumerate(self.hidden_layers):
            fc_layer = nn.Linear(in_layer, hidden_layer)
            in_layer = hidden_layer
            self.__setattr__("fc_layer{}".format(i), fc_layer)
            self.fc_layers.append(fc_layer)

        
        self.last_fc_layer = nn.Linear(hidden_dim, output_dim)
        self.last_fc_layer.weight.data.uniform_(-init_w, init_w)
        self.last_fc_layer.bias.data.uniform_(-init_w, init_w)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        for fc_layer in self.fc_layers:
            x = self.hidden_activation(fc_layer(x))
        x = self.last_fc_layer(x)
        return x


class FlattenMLP(MLP):
    def forward(self, *x: Tuple[torch.Tensor, torch.Tensor]) -> torch.Tensor:
        x = torch.cat(x, dim=-1)
        return super().forward(x)


class MLPEncoder(FlattenMLP):
    def __init__(
        self,
        input_dim: int,
        output_dim: int,
        latent_dim: int,
        hidden_dim: int,
        device: torch.device,
    ) -> None:
        super().__init__(input_dim=input_dim, output_dim=output_dim, hidden_dim=hidden_dim)

        self.output_dim = output_dim
        self.latent_dim = latent_dim
        self.device = device

        self.z_mean = None
        self.z_var = None
        self.task_z = None
        self.clear_z()

    def clear_z(self, num_tasks: int = 1) -> None:
        
        self.z_mean = torch.zeros(num_tasks, self.latent_dim).to(self.device)
        self.z_var = torch.ones(num_tasks, self.latent_dim).to(self.device)

        
        self.sample_z()

        
        self.context = None

    def sample_z(self) -> None:
        
        dists = []
        for mean, var in zip(torch.unbind(self.z_mean), torch.unbind(self.z_var)):
            
            if not torch.isfinite(mean).all() or not torch.isfinite(var).all():
                raise ValueError("Mean or variance contains NaN or inf values.")

            
            if (var < 0).any():
                raise ValueError("Variance must be non-negative.")
        for mean, var in zip(torch.unbind(self.z_mean), torch.unbind(self.z_var)):
            dist = torch.distributions.Normal(mean, torch.sqrt(abs(var)))
            dists.append(dist)
        sampled_z = [dist.rsample() for dist in dists]
        self.task_z = torch.stack(sampled_z).to(self.device)

    @classmethod
    def product_of_gaussians(
        cls,
        mean: torch.Tensor,
        var: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        
        var = torch.clamp(var, min=1e-7)
        pog_var = 1.0 / torch.sum(torch.reciprocal(var), dim=0)
        pog_mean = pog_var * torch.sum(mean / var, dim=0)
        return pog_mean, pog_var

    def infer_posterior(self, context: torch.Tensor) -> None:
        
        if context.shape==(4,256,14):
         context=context[0]
        
        params = self.forward(context)
        

        
        z_mean = torch.unbind(params[..., : self.latent_dim])
        z_var = torch.unbind(F.softplus(params[..., self.latent_dim :]))
        z_params = [self.product_of_gaussians(mu, var) for mu, var in zip(z_mean, z_var)]

        self.z_mean = torch.stack([z_param[0] for z_param in z_params]).to(self.device)
        self.z_var = torch.stack([z_param[1] for z_param in z_params]).to(self.device)
        self.sample_z()

    def compute_kl_div(self) -> torch.Tensor:
        
        prior = torch.distributions.Normal(
            torch.zeros(self.latent_dim).to(self.device),
            torch.ones(self.latent_dim).to(self.device),
        )

        posteriors = []
        for mean, var in zip(torch.unbind(self.z_mean), torch.unbind(self.z_var)):
            dist = torch.distributions.Normal(mean, torch.sqrt(var))
            posteriors.append(dist)

        kl_div = [torch.distributions.kl.kl_divergence(posterior, prior) for posterior in posteriors]
        kl_div = torch.stack(kl_div).sum().to(self.device)
        return kl_div


LOG_SIG_MAX = 2
LOG_SIG_MIN = -20

class SelfAttention(nn.Module):
    def __init__(self, input_dim, num_heads):
        super(SelfAttention, self).__init__()
        self.num_heads = num_heads
        self.head_dim = input_dim // num_heads
        self.fc_q = nn.Linear(input_dim, input_dim)
        self.fc_k = nn.Linear(input_dim, input_dim)
        self.fc_v = nn.Linear(input_dim, input_dim)
        self.fc_o = nn.Linear(input_dim, input_dim)

    def forward(self, x):

        D1, D2, D3= 1, 1, 1
        two_d_tensor = x.unsqueeze(0)
        four_d_tensor = two_d_tensor.repeat(D1, D2, D3)
        batch_size = four_d_tensor.shape[0]
        q = self.fc_q(four_d_tensor).view(batch_size, self.num_heads, -1, self.head_dim).permute(0, 2, 1, 3)
        k = self.fc_k(four_d_tensor).view(batch_size, self.num_heads, -1, self.head_dim).permute(0, 2, 1, 3)
        v = self.fc_v(four_d_tensor).view(batch_size, self.num_heads, -1, self.head_dim).permute(0, 2, 1, 3)

        energy = torch.matmul(q, k.permute(0, 1, 3, 2)) / np.sqrt(self.head_dim)
        
        attention = torch.nn.functional.softmax(energy, dim=-1)
        four_d_tensor = torch.matmul(attention, v).permute(0, 2, 1, 3).contiguous().view(batch_size, -1, x.shape[-1])
        four_d_tensor = self.fc_o(four_d_tensor)
        return four_d_tensor

class TanhGaussianPolicy(MLP):
    def __init__(
        self,
        input_dim: int,
        output_dim: int,
        hidden_dim: int,
        is_deterministic: bool = False,
        init_w: float = 1e-3,
    ) -> None:
        super().__init__(
            input_dim=input_dim,
            output_dim=output_dim,
            hidden_dim=hidden_dim,
            init_w=init_w,
        )

        self.is_deterministic = is_deterministic
        self.last_fc_log_std = nn.Linear(hidden_dim, output_dim)
        self.last_fc_log_std.weight.data.uniform_(-init_w, init_w)
        self.last_fc_log_std.bias.data.uniform_(-init_w, init_w)
        self.multi_head_attention = SelfAttention(3, 1)

    def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        for fc_layer in self.fc_layers:
            x = self.multi_head_attention(fc_layer(x))
            x = self.hidden_activation(fc_layer(x))

        mean = self.last_fc_layer(x)
        log_std = self.last_fc_log_std(x)
        log_std = torch.clamp(log_std, LOG_SIG_MIN, LOG_SIG_MAX)
        std = torch.exp(log_std)

        if self.is_deterministic:
            action = mean
            log_prob = None
        else:
            normal = Normal(mean, std)
            action = normal.rsample()

            
            log_prob = normal.log_prob(action)
            log_prob -= 2 * (np.log(2) - action - F.softplus(-2 * action))
            log_prob = log_prob.sum(-1, keepdim=True)

        action = torch.tanh(action)
        action = action*0.5+0.5

        return action, log_prob
