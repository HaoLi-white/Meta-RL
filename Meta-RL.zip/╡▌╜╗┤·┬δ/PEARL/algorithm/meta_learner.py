import datetime
import os
import time
import warnings
from collections import deque
from typing import Any, Dict, List

warnings.filterwarnings("ignore")

import numpy as np
import torch
from gym.envs.mujoco.half_cheetah import HalfCheetahEnv
from torch.utils.tensorboard import SummaryWriter
from tqdm import tqdm

from algorithm.buffers import MultiTaskReplayBuffer
from algorithm.sac import SAC
from algorithm.sampler import Sampler
import matplotlib.pyplot as plt
import pandas as pd

class MetaLearner:
    def __init__(
        self,
        env: HalfCheetahEnv,
        env1: HalfCheetahEnv,
        env2: HalfCheetahEnv,
        env3: HalfCheetahEnv,
        env4:HalfCheetahEnv,
        env5:HalfCheetahEnv,
        env_name: str,
        agent: SAC,
        observ_dim: int,
        action_dim: int,
        train_tasks: List[int],
        test_tasks: List[int],
        save_exp_name: str,
        save_file_name: str,
        load_exp_name: str,
        load_file_name: str,
        load_ckpt_num: int,
        device: torch.device,
        **config,
    ) -> None:
        self.env = env
        self.env1 = env1
        self.env2 = env2
        self.env3 = env3
        self.env4 = env4
        self.env5 = env5
        self.env_name = env_name
        self.agent = agent
        self.train_tasks = train_tasks
        self.test_tasks = test_tasks
        self.device = device
        self.return_list=[]
        self.num_iterations: int = config["num_iterations"]
        self.num_sample_tasks: int = config["num_sample_tasks"]


        self.num_init_samples: int = config["num_init_samples"]
        self.num_prior_samples: int = config["num_prior_samples"]
        self.num_posterior_samples: int = config["num_posterior_samples"]

        self.num_meta_grads: int = config["num_meta_grads"]
        self.meta_batch_size: int = config["meta_batch_size"]
        self.batch_size: int = config["batch_size"]
        self.max_step: int = config["max_step"]

        self.sampler = Sampler(env=env,env1=env1,env2=env2,env3=env3,env4=env4,env5=env5, agent=agent, max_step=config["max_step"], device=device)

        
        
        
        self.rl_replay_buffer = MultiTaskReplayBuffer(
            observ_dim=observ_dim,
            action_dim=action_dim,
            tasks=train_tasks,
            max_size=config["max_buffer_size"],
        )
        self.encoder_replay_buffer = MultiTaskReplayBuffer(
            observ_dim=observ_dim,
            action_dim=action_dim,
            tasks=train_tasks,
            max_size=config["max_buffer_size"],
        )

        if not save_file_name:
            save_file_name = datetime.datetime.now().strftime("%Y-%m-%d-%H-%M-%S")
        self.result_path = os.path.join("results", save_exp_name, save_file_name)

        

        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        

    def collect_test_action(
        self,
        task_index: int,
        max_samples: int,
        update_posterior: bool,
        add_to_enc_buffer: bool,
        tasknumber:int,
    ) -> None:
        
        self.agent.encoder.clear_z()
        self.agent.policy.is_deterministic = False

        cur_samples = 0
        while cur_samples < max_samples:
            trajs, num_samples,reward = self.sampler.obtain_samples_action(
                max_samples=max_samples - cur_samples,
                update_posterior=update_posterior,
                task=tasknumber,
                accum_context=False,

            )
            cur_samples += num_samples

            
            self.rl_replay_buffer.add_trajs(task_index, trajs)
            if add_to_enc_buffer:
                
                self.encoder_replay_buffer.add_trajs(task_index, trajs)

            if update_posterior:
                
                context_batch = self.sample_context(np.array([task_index]))
                self.agent.encoder.infer_posterior(context_batch)

        return reward



    def collect_train_data(
        self,
        task_index: int,
        max_samples: int,
        update_posterior: bool,
        add_to_enc_buffer: bool,
    ) -> None:
        
        self.agent.encoder.clear_z()
        self.agent.policy.is_deterministic = False

        cur_samples = 0
        while cur_samples < max_samples:
            trajs, num_samples,reward = self.sampler.obtain_train_samples(
                max_samples=max_samples - cur_samples,
                update_posterior=update_posterior,
                accum_context=False,
            )
            cur_samples += num_samples

            
            self.rl_replay_buffer.add_trajs(task_index, trajs)
            if add_to_enc_buffer:
                
                self.encoder_replay_buffer.add_trajs(task_index, trajs)

            if update_posterior:
                
                context_batch = self.sample_context(np.array([task_index]))
                self.agent.encoder.infer_posterior(context_batch)

        return reward

    def collect_test_data1(
        self,
        task_index: int,
        max_samples: int,
        update_posterior: bool,
        add_to_enc_buffer: bool,
    ) -> None:
        
        self.agent.encoder.clear_z()
        self.agent.policy.is_deterministic = False

        cur_samples = 0
        while cur_samples < max_samples:
            trajs, num_samples,reward = self.sampler.obtain_samples1(
                max_samples=max_samples - cur_samples,
                update_posterior=update_posterior,
                accum_context=False,
            )
            cur_samples += num_samples

            
            self.rl_replay_buffer.add_trajs(task_index, trajs)
            if add_to_enc_buffer:
                
                self.encoder_replay_buffer.add_trajs(task_index, trajs)

            if update_posterior:
                
                context_batch = self.sample_context(np.array([task_index]))
                self.agent.encoder.infer_posterior(context_batch)

        return reward
    def collect_test_data2(
        self,
        task_index: int,
        max_samples: int,
        update_posterior: bool,
        add_to_enc_buffer: bool,
    ) -> None:
        
        self.agent.encoder.clear_z()
        self.agent.policy.is_deterministic = False

        cur_samples = 0
        while cur_samples < max_samples:
            trajs, num_samples,reward = self.sampler.obtain_samples2(
                max_samples=max_samples - cur_samples,
                update_posterior=update_posterior,
                accum_context=False,
            )
            cur_samples += num_samples

            
            self.rl_replay_buffer.add_trajs(task_index, trajs)
            if add_to_enc_buffer:
                
                self.encoder_replay_buffer.add_trajs(task_index, trajs)

            if update_posterior:
                
                context_batch = self.sample_context(np.array([task_index]))
                self.agent.encoder.infer_posterior(context_batch)
        return reward
    def collect_test_data3(
        self,
        task_index: int,
        max_samples: int,
        update_posterior: bool,
        add_to_enc_buffer: bool,
    ) -> None:
        
        self.agent.encoder.clear_z()
        self.agent.policy.is_deterministic = False

        cur_samples = 0
        while cur_samples < max_samples:
            trajs, num_samples,reward = self.sampler.obtain_samples3(
                max_samples=max_samples - cur_samples,
                update_posterior=update_posterior,
                accum_context=False,
            )
            cur_samples += num_samples

            
            self.rl_replay_buffer.add_trajs(task_index, trajs)
            if add_to_enc_buffer:
                
                self.encoder_replay_buffer.add_trajs(task_index, trajs)

            if update_posterior:
                
                context_batch = self.sample_context(np.array([task_index]))
                self.agent.encoder.infer_posterior(context_batch)
        return reward
    def collect_test_data4(
            self,
            task_index: int,
            max_samples: int,
            update_posterior: bool,
            add_to_enc_buffer: bool,
    ) -> None:
        
        self.agent.encoder.clear_z()
        self.agent.policy.is_deterministic = False

        cur_samples = 0
        while cur_samples < max_samples:
            trajs, num_samples,reward = self.sampler.obtain_samples4(
                max_samples=max_samples - cur_samples,
                update_posterior=update_posterior,
                accum_context=False,
            )
            cur_samples += num_samples

            
            self.rl_replay_buffer.add_trajs(task_index, trajs)
            if add_to_enc_buffer:
                
                self.encoder_replay_buffer.add_trajs(task_index, trajs)

            if update_posterior:
                
                context_batch = self.sample_context(np.array([task_index]))
                self.agent.encoder.infer_posterior(context_batch)
        return reward

    def collect_test_data5(
            self,
            task_index: int,
            max_samples: int,
            update_posterior: bool,
            add_to_enc_buffer: bool,
    ) -> None:
        
        self.agent.encoder.clear_z()
        self.agent.policy.is_deterministic = False

        cur_samples = 0
        while cur_samples < max_samples:
            trajs, num_samples,reward = self.sampler.obtain_samples5(
                max_samples=max_samples - cur_samples,
                update_posterior=update_posterior,
                accum_context=False,
            )
            cur_samples += num_samples

            
            self.rl_replay_buffer.add_trajs(task_index, trajs)
            if add_to_enc_buffer:
                
                self.encoder_replay_buffer.add_trajs(task_index, trajs)

            if update_posterior:
                
                context_batch = self.sample_context(np.array([task_index]))
                self.agent.encoder.infer_posterior(context_batch)
        return reward

    def sample_context(self, indices: np.ndarray) -> torch.Tensor:
        
        context_batch = []
        for index in indices:
            batch = self.encoder_replay_buffer.sample_batch(task=index, batch_size=self.batch_size)
            context_batch.append(
                np.concatenate((batch["cur_obs"], batch["actions"], batch["rewards"]), axis=-1),
            )
        return torch.Tensor(context_batch).to(self.device)

    def sample_transition(self, indices: np.ndarray) -> List[torch.Tensor]:
        
        cur_obs, actions, rewards, next_obs, dones = [], [], [], [], []
        for index in indices:
            batch = self.rl_replay_buffer.sample_batch(task=index, batch_size=self.batch_size)
            cur_obs.append(batch["cur_obs"])
            actions.append(batch["actions"])
            rewards.append(batch["rewards"])
            next_obs.append(batch["next_obs"])
            dones.append(batch["dones"])

        cur_obs = torch.Tensor(cur_obs).view(len(indices), self.batch_size, -1).to(self.device)
        actions = torch.Tensor(actions).view(len(indices), self.batch_size, -1).to(self.device)
        rewards = torch.Tensor(rewards).view(len(indices), self.batch_size, -1).to(self.device)
        next_obs = torch.Tensor(next_obs).view(len(indices), self.batch_size, -1).to(self.device)
        dones = torch.Tensor(dones).view(len(indices), self.batch_size, -1).to(self.device)
        return [cur_obs, actions, rewards, next_obs, dones]

    def meta_train(self) -> None:
        
            total_start_time: float = time.time()
        
            rewards0 = []
            rewards1 = []
            rewards2 = []
            rewards3 = []
            rewards4 = []
            rewards5 = []
            reward00 = 0
            reward11 = 0
            reward22 = 0
            reward33 = 0
            reward44 = 0
            reward55 = 0
            reward0 = 0
            reward1 = 0
            reward2 = 0
            reward3 = 0
            reward4 = 0
            reward5 = 0
            
            
            
            for iteration in range (100):
                    print(f"\n=============== train-{iteration+1} ===============")
                    rewards0 = []
                    for index in tqdm(self.train_tasks):
                        self.env.reset_task(index)
                        reward00=self.collect_train_data(
                            task_index=index,
                            max_samples=self.num_init_samples,
                            update_posterior=False,
                            add_to_enc_buffer=True,
                        )
                        rewards0.append(reward00)
                    reward0 = max(rewards0)
                    print(f"train--{reward0}")
                    self.return_list.append(reward0)
                    for i in range(self.num_meta_grads):
                        indices: np.ndarray = np.random.choice(self.train_tasks, self.meta_batch_size)

                        
                        self.agent.encoder.clear_z(num_tasks=len(indices))

                        
                        context_batch: torch.Tensor = self.sample_context(indices)

                        
                        transition_batch: List[torch.Tensor] = self.sample_transition(indices)

                        
                        log_values: Dict[str, float] = self.agent.train_model(
                            meta_batch_size=self.meta_batch_size,
                            batch_size=self.batch_size,
                            context_batch=context_batch,
                            transition_batch=transition_batch,
                        )

                        
                        self.agent.encoder.task_z.detach()
            
            for iteration in range (20):
                    print(f"\n=============== new task1 ===============")
                    if iteration == 0:
                        print("Collecting initial pool of data for train and eval")
                        for index in tqdm(self.train_tasks):
                            
                            self.collect_test_data1(
                                task_index=0,
                                max_samples=self.num_init_samples,
                                update_posterior=False,
                                add_to_enc_buffer=True,
                            )
                    rewards1=[]
                    for i in range(self.num_sample_tasks):
                        
                        
                        self.encoder_replay_buffer.task_buffers[0].clear()

                        
                        if self.num_prior_samples > 0:
                            if iteration<=18:
                                print(f"[{i + 1}/{self.num_sample_tasks}] collecting samples with prior")
                                reward11=self.collect_test_data1(
                                    task_index=0,
                                    max_samples=self.num_prior_samples,
                                    update_posterior=False,
                                    add_to_enc_buffer=True,
                                )
                                rewards1.append(reward11)
                            if iteration == 19:
                                print(f"[{i + 1}/{self.num_sample_tasks}] collecting samples with prior")
                                reward11 = self.collect_test_action(
                                    task_index=0,
                                    max_samples=self.num_prior_samples,
                                    update_posterior=False,
                                    add_to_enc_buffer=True,
                                    tasknumber=1,
                                )
                                rewards1.append(reward11)
                        
                        
                        if self.num_posterior_samples > 0:
                            if iteration <= 18:
                                print(f"[{i + 1}/{self.num_sample_tasks}] collecting samples with posterior")
                                reward11 = self.collect_test_data1(
                                    task_index=0,
                                    max_samples=self.num_posterior_samples,
                                    update_posterior=True,
                                    add_to_enc_buffer=False,
                                )
                                rewards1.append(reward11)
                            if iteration == 19:
                                print(f"[{i + 1}/{self.num_sample_tasks}] collecting samples with posterior")
                                reward11 = self.collect_test_action(
                                    task_index=0,
                                    max_samples=self.num_posterior_samples,
                                    update_posterior=True,
                                    add_to_enc_buffer=False,
                                    tasknumber=1,
                                )
                                rewards1.append(reward11)
                    reward1= max(rewards1)
                    print(f"[{1}--{reward1}]")
                    self.return_list.append(reward1)
                    
                    for i in range(self.num_meta_grads):
                        indices: np.ndarray = np.random.choice(self.train_tasks, self.meta_batch_size)

                        
                        self.agent.encoder.clear_z(num_tasks=len(indices))

                        
                        context_batch: torch.Tensor = self.sample_context(indices)

                        
                        transition_batch: List[torch.Tensor] = self.sample_transition(indices)

                        
                        log_values: Dict[str, float] = self.agent.train_model(
                            meta_batch_size=self.meta_batch_size,
                            batch_size=self.batch_size,
                            context_batch=context_batch,
                            transition_batch=transition_batch,
                        )

                        
                        self.agent.encoder.task_z.detach()

            for iteration in range(20):
                    print(f"\n=============== new task2 ===============")
                    if iteration == 0:
                        print("Collecting initial pool of data for train and eval")
                        for index in tqdm(self.train_tasks):
                            
                            self.collect_test_data2(
                                task_index=1,
                                max_samples=self.num_init_samples,
                                update_posterior=False,
                                add_to_enc_buffer=True,
                            )
                    rewards2=[]
                    for i in range(self.num_sample_tasks):
                        
                        self.encoder_replay_buffer.task_buffers[1].clear()
                        
                        if self.num_prior_samples > 0:
                            if iteration <= 18:
                                print(f"[{i + 1}/{self.num_sample_tasks}] collecting samples with prior")
                                reward22 = self.collect_test_data2(
                                    task_index=1,
                                    max_samples=self.num_prior_samples,
                                    update_posterior=False,
                                    add_to_enc_buffer=True,
                                )
                                rewards2.append(reward22)
                            if iteration == 19:
                                print(f"[{i + 1}/{self.num_sample_tasks}] collecting samples with prior")
                                reward22 = self.collect_test_action(
                                    task_index=1,
                                    max_samples=self.num_prior_samples,
                                    update_posterior=False,
                                    add_to_enc_buffer=True,
                                    tasknumber=2,
                                )
                                rewards2.append(reward22)
                        
                        
                        if self.num_posterior_samples > 0:
                            if iteration <= 18:
                                print(f"[{i + 1}/{self.num_sample_tasks}] collecting samples with posterior")
                                reward22 = self.collect_test_data2(
                                    task_index=1,
                                    max_samples=self.num_posterior_samples,
                                    update_posterior=True,
                                    add_to_enc_buffer=False,
                                )
                                rewards2.append(reward22)
                            if iteration == 19:
                                print(f"[{i + 1}/{self.num_sample_tasks}] collecting samples with posterior")
                                reward2 = self.collect_test_action(
                                    task_index=1,
                                    max_samples=self.num_posterior_samples,
                                    update_posterior=True,
                                    add_to_enc_buffer=False,
                                    tasknumber=2,
                                )
                                rewards2.append(reward22)
                    reward2 = max(rewards2)
                    print(f"[{2}--{reward2}]")
                    self.return_list.append(reward2)
                    
                
                    for i in range(self.num_meta_grads):
                        indices: np.ndarray = np.random.choice(self.train_tasks, self.meta_batch_size)

                        
                        self.agent.encoder.clear_z(num_tasks=len(indices))

                        
                        context_batch: torch.Tensor = self.sample_context(indices)

                        
                        transition_batch: List[torch.Tensor] = self.sample_transition(indices)

                        
                        log_values: Dict[str, float] = self.agent.train_model(
                            meta_batch_size=self.meta_batch_size,
                            batch_size=self.batch_size,
                            context_batch=context_batch,
                            transition_batch=transition_batch,
                        )

                        
                        self.agent.encoder.task_z.detach()

            for iteration in range(20):
                    print(f"\n=============== new task3 ===============")
                    if iteration == 0:
                        print("Collecting initial pool of data for train and eval")
                        for index in tqdm(self.train_tasks):
                            
                            self.collect_test_data3(
                                task_index=2,
                                max_samples=self.num_init_samples,
                                update_posterior=False,
                                add_to_enc_buffer=True,
                            )
                    rewards3=[]
                    for i in range(self.num_sample_tasks):
                        
                        self.encoder_replay_buffer.task_buffers[2].clear()
                        
                        if self.num_prior_samples > 0:
                            if iteration <= 18:
                                print(f"[{i + 1}/{self.num_sample_tasks}] collecting samples with prior")
                                reward33 = self.collect_test_data3(
                                    task_index=2,
                                    max_samples=self.num_prior_samples,
                                    update_posterior=False,
                                    add_to_enc_buffer=True,
                                )
                                rewards3.append(reward33)
                            if iteration == 19:
                                print(f"[{i + 1}/{self.num_sample_tasks}] collecting samples with prior")
                                reward33 = self.collect_test_action(
                                    task_index=2,
                                    max_samples=self.num_prior_samples,
                                    update_posterior=False,
                                    add_to_enc_buffer=True,
                                    tasknumber=3,
                                )
                                rewards3.append(reward33)
                        
                        
                        if self.num_posterior_samples > 0:
                            if iteration <= 18:
                                print(f"[{i + 1}/{self.num_sample_tasks}] collecting samples with posterior")
                                reward33 = self.collect_test_data3(
                                    task_index=2,
                                    max_samples=self.num_posterior_samples,
                                    update_posterior=True,
                                    add_to_enc_buffer=False,
                                )
                                rewards3.append(reward33)
                            if iteration == 19:
                                print(f"[{i + 1}/{self.num_sample_tasks}] collecting samples with posterior")
                                reward33 = self.collect_test_action(
                                    task_index=2,
                                    max_samples=self.num_posterior_samples,
                                    update_posterior=True,
                                    add_to_enc_buffer=False,
                                    tasknumber=3,
                                )
                                rewards3.append(reward33)
                    reward3 = max(rewards3)
                    print(f"[{3}--{reward3}]")
                    self.return_list.append(reward3)
                
                
                    for i in range(self.num_meta_grads):
                        indices: np.ndarray = np.random.choice(self.train_tasks, self.meta_batch_size)

                        
                        self.agent.encoder.clear_z(num_tasks=len(indices))

                        
                        context_batch: torch.Tensor = self.sample_context(indices)

                        
                        transition_batch: List[torch.Tensor] = self.sample_transition(indices)

                        
                        log_values: Dict[str, float] = self.agent.train_model(
                            meta_batch_size=self.meta_batch_size,
                            batch_size=self.batch_size,
                            context_batch=context_batch,
                            transition_batch=transition_batch,
                        )

                        
                        self.agent.encoder.task_z.detach()

            for iteration in range(20):
                    print(f"\n=============== new task4 ===============")
                    if iteration == 0:
                        print("Collecting initial pool of data for train and eval")
                        for index in tqdm(self.train_tasks):
                            
                            self.collect_test_data4(
                                task_index=3,
                                max_samples=self.num_init_samples,
                                update_posterior=False,
                                add_to_enc_buffer=True,
                            )
                    reward4=[]
                    for i in range(self.num_sample_tasks):
                        
                        self.encoder_replay_buffer.task_buffers[3].clear()
                        
                        if self.num_prior_samples > 0:
                            if iteration <= 18:
                                print(f"[{i + 1}/{self.num_sample_tasks}] collecting samples with prior")
                                reward44 = self.collect_test_data4(
                                    task_index=3,
                                    max_samples=self.num_prior_samples,
                                    update_posterior=False,
                                    add_to_enc_buffer=True,
                                )
                                rewards4.append(reward44)
                            if iteration == 19:
                                print(f"[{i + 1}/{self.num_sample_tasks}] collecting samples with prior")
                                reward44 = self.collect_test_action(
                                    task_index=3,
                                    max_samples=self.num_prior_samples,
                                    update_posterior=False,
                                    add_to_enc_buffer=True,
                                    tasknumber=4,
                                )
                                rewards4.append(reward44)
                        
                        
                        if self.num_posterior_samples > 0:
                            if iteration <= 18:
                                print(f"[{i + 1}/{self.num_sample_tasks}] collecting samples with posterior")
                                reward44 = self.collect_test_data4(
                                    task_index=3,
                                    max_samples=self.num_posterior_samples,
                                    update_posterior=True,
                                    add_to_enc_buffer=False,
                                )
                                rewards4.append(reward44)
                            if iteration == 19:
                                print(f"[{i + 1}/{self.num_sample_tasks}] collecting samples with posterior")
                                reward44 = self.collect_test_action(
                                    task_index=3,
                                    max_samples=self.num_posterior_samples,
                                    update_posterior=True,
                                    add_to_enc_buffer=False,
                                    tasknumber=4,
                                )
                                rewards4.append(reward44)
                    reward4 = max(rewards4)
                    print(f"[{4}--{reward4}]")
                    self.return_list.append(reward4)
                    
                
                    for i in range(self.num_meta_grads):
                        indices: np.ndarray = np.random.choice(self.train_tasks, self.meta_batch_size)

                        
                        self.agent.encoder.clear_z(num_tasks=len(indices))

                        
                        context_batch: torch.Tensor = self.sample_context(indices)

                        
                        transition_batch: List[torch.Tensor] = self.sample_transition(indices)

                        
                        log_values: Dict[str, float] = self.agent.train_model(
                            meta_batch_size=self.meta_batch_size,
                            batch_size=self.batch_size,
                            context_batch=context_batch,
                            transition_batch=transition_batch,
                        )

                        
                        self.agent.encoder.task_z.detach()

            for iteration in range(20):
                print(f"\n=============== new task5 ===============")
                if iteration == 0:
                    print("Collecting initial pool of data for train and eval")
                    for index in tqdm(self.train_tasks):
                        
                        self.collect_test_data5(
                            task_index=4,
                            max_samples=self.num_init_samples,
                            update_posterior=False,
                            add_to_enc_buffer=True,
                        )
                reward5 = []
                for i in range(self.num_sample_tasks):
                    
                    self.encoder_replay_buffer.task_buffers[4].clear()
                    
                    if self.num_prior_samples > 0:
                        if iteration <= 18:
                            print(f"[{i + 1}/{self.num_sample_tasks}] collecting samples with prior")
                            reward55 = self.collect_test_data5(
                                task_index=4,
                                max_samples=self.num_prior_samples,
                                update_posterior=False,
                                add_to_enc_buffer=True,
                            )
                            rewards5.append(reward55)
                        if iteration == 19:
                            print(f"[{i + 1}/{self.num_sample_tasks}] collecting samples with prior")
                            reward55 = self.collect_test_action(
                                task_index=4,
                                max_samples=self.num_prior_samples,
                                update_posterior=False,
                                add_to_enc_buffer=True,
                                tasknumber=5,
                            )
                            rewards5.append(reward55)
                    
                    
                    if self.num_posterior_samples > 0:
                        if iteration <= 18:
                            print(f"[{i + 1}/{self.num_sample_tasks}] collecting samples with posterior")
                            reward55 = self.collect_test_data5(
                                task_index=4,
                                max_samples=self.num_posterior_samples,
                                update_posterior=True,
                                add_to_enc_buffer=False,
                            )
                            rewards5.append(reward55)
                        if iteration == 19:
                            print(f"[{i + 1}/{self.num_sample_tasks}] collecting samples with posterior")
                            reward55 = self.collect_test_action(
                                task_index=4,
                                max_samples=self.num_posterior_samples,
                                update_posterior=True,
                                add_to_enc_buffer=False,
                                tasknumber=5,
                            )
                            rewards5.append(reward55)
                reward5 = max(rewards5)
                print(f"[{5}--{reward5}]")
                self.return_list.append(reward5)
                
                
                for i in range(self.num_meta_grads):
                    indices: np.ndarray = np.random.choice(self.train_tasks, self.meta_batch_size)

                    
                    self.agent.encoder.clear_z(num_tasks=len(indices))

                    
                    context_batch: torch.Tensor = self.sample_context(indices)

                    
                    transition_batch: List[torch.Tensor] = self.sample_transition(indices)

                    
                    log_values: Dict[str, float] = self.agent.train_model(
                        meta_batch_size=self.meta_batch_size,
                        batch_size=self.batch_size,
                        context_batch=context_batch,
                        transition_batch=transition_batch,
                    )

                    
                    self.agent.encoder.task_z.detach()
            plt.plot(list(range(len(self.return_list))), self.return_list)
            plt.xlabel('Episodes')
            plt.ylabel('Returns')
            plt.title('ATTPEMARL-meta on {}'.format(self.env_name))
            plt.savefig('reward-1.jpg')
            df = pd.DataFrame(self.return_list)
            df.to_excel("return_list——1.xlsx", index=False)
            plt.show()
            
            

            
            
            
            
            
            
            
            

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

    def visualize_within_tensorboard(self, test_results: Dict[str, Any], iteration: int) -> None:
        
        self.writer.add_scalar(
            "test/return_before_infer",
            test_results["return_before_infer"],
            iteration,
        )
        self.writer.add_scalar("test/return_after_infer", test_results["return_after_infer"], iteration)
        if self.env_name == "vel":
            self.writer.add_scalar(
                "test/sum_run_cost_before_infer",
                test_results["sum_run_cost_before_infer"],
                iteration,
            )
            self.writer.add_scalar(
                "test/sum_run_cost_after_infer",
                test_results["sum_run_cost_after_infer"],
                iteration,
            )
            for step in range(len(test_results["run_cost_before_infer"])):
                self.writer.add_scalar(
                    "run_cost_before_infer/iteration_" + str(iteration),
                    test_results["run_cost_before_infer"][step],
                    step,
                )
                self.writer.add_scalar(
                    "run_cost_after_infer/iteration_" + str(iteration),
                    test_results["run_cost_after_infer"][step],
                    step,
                )
        self.writer.add_scalar("train/policy_loss", test_results["policy_loss"], iteration)
        self.writer.add_scalar("train/qf1_loss", test_results["qf1_loss"], iteration)
        self.writer.add_scalar("train/qf2_loss", test_results["qf2_loss"], iteration)
        self.writer.add_scalar("train/encoder_loss", test_results["encoder_loss"], iteration)
        self.writer.add_scalar("train/alpha_loss", test_results["alpha_loss"], iteration)
        self.writer.add_scalar("train/alpha", test_results["alpha"], iteration)
        self.writer.add_scalar("train/z_mean", test_results["z_mean"], iteration)
        self.writer.add_scalar("train/z_var", test_results["z_var"], iteration)
        self.writer.add_scalar("time/total_time", test_results["total_time"], iteration)
        self.writer.add_scalar("time/time_per_iter", test_results["time_per_iter"], iteration)

    def meta_test(
        self,
        iteration: int,
        total_start_time: float,
        start_time: float,
        log_values: Dict[str, float],
    ) -> None:
        
        test_results = {}
        return_before_infer = 0
        return_after_infer = 0
        run_cost_before_infer = np.zeros(self.max_step)
        run_cost_after_infer = np.zeros(self.max_step)

        for index in self.test_tasks:
            
            trajs: List[List[Dict[str, np.ndarray]]] = self.collect_test_data(
                max_samples=self.max_step * 2,
                update_posterior=True,
            )

            return_before_infer += np.sum(trajs[0][0]["rewards"])
            return_after_infer += np.sum(trajs[1][0]["rewards"])
            if self.env_name == "vel":
                for i in range(self.max_step):
                    run_cost_before_infer[i] += trajs[0][0]["infos"][i]
                    run_cost_after_infer[i] += trajs[1][0]["infos"][i]

        test_results["return_before_infer"] = return_before_infer / len(self.test_tasks)
        test_results["return_after_infer"] = return_after_infer / len(self.test_tasks)
        if self.env_name == "vel":
            test_results["run_cost_before_infer"] = run_cost_before_infer / len(self.test_tasks)
            test_results["run_cost_after_infer"] = run_cost_after_infer / len(self.test_tasks)
            test_results["sum_run_cost_before_infer"] = sum(
                abs(run_cost_before_infer / len(self.test_tasks)),
            )
            test_results["sum_run_cost_after_infer"] = sum(
                abs(run_cost_after_infer / len(self.test_tasks)),
            )
        test_results["policy_loss"] = log_values["policy_loss"]
        test_results["qf1_loss"] = log_values["qf1_loss"]
        test_results["qf2_loss"] = log_values["qf2_loss"]
        test_results["encoder_loss"] = log_values["encoder_loss"]
        test_results["alpha_loss"] = log_values["alpha_loss"]
        test_results["alpha"] = log_values["alpha"]
        test_results["z_mean"] = log_values["z_mean"]
        test_results["z_var"] = log_values["z_var"]
        test_results["total_time"] = time.time() - total_start_time
        test_results["time_per_iter"] = time.time() - start_time

        self.visualize_within_tensorboard(test_results, iteration)

        
        if self.env_name == "dir":
            self.dq.append(test_results["return_after_infer"])
            if all(list(map((lambda x: x >= self.stop_goal), self.dq))):
                self.is_early_stopping = True
        elif self.env_name == "vel":
            self.dq.append(test_results["sum_run_cost_after_infer"])
            if all(list(map((lambda x: x <= self.stop_goal), self.dq))):
                self.is_early_stopping = True

        
        if self.is_early_stopping:
            ckpt_path = os.path.join(self.result_path, "checkpoint_" + str(iteration) + ".pt")
            torch.save(
                {
                    "policy": self.agent.policy.state_dict(),
                    "encoder": self.agent.encoder.state_dict(),
                    "qf1": self.agent.qf1.state_dict(),
                    "qf2": self.agent.qf2.state_dict(),
                    "target_qf1": self.agent.target_qf1.state_dict(),
                    "target_qf2": self.agent.target_qf2.state_dict(),
                    "log_alpha": self.agent.log_alpha,
                    "alpha": self.agent.alpha,
                    "rl_replay_buffer": self.rl_replay_buffer,
                    "encoder_replay_buffer": self.encoder_replay_buffer,
                },
                ckpt_path,
            )
