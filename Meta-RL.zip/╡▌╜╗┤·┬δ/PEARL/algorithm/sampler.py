from typing import Dict, List, Tuple

import numpy as np
import torch
from gym.envs.mujoco.half_cheetah import HalfCheetahEnv

from algorithm.sac import SAC



class Sampler:
    def __init__(
        self,
        env: HalfCheetahEnv,
        env1: HalfCheetahEnv,
        env2: HalfCheetahEnv,
        env3: HalfCheetahEnv,
        env4: HalfCheetahEnv,
        env5: HalfCheetahEnv,
        agent: SAC,
        max_step: int,
        device: torch.device,
    ) -> None:

        self.env = env
        self.env1 = env1
        self.env2 = env2
        self.env3 = env3
        self.env4 = env4
        self.env5 = env5
        self.agent = agent
        self.max_step = max_step
        self.device = device

    def obtain_samples_action(
            self,
            max_samples: int,
            update_posterior: bool,
            task:int,
            accum_context: bool = True,
    ) -> Tuple[List[Dict[str, np.ndarray]], int]:
        
        trajs = []
        cur_samples = 0
        reward = 0
        while cur_samples < max_samples:
            if task==1:
                traj, reward = self.rollout_action1(accum_context=accum_context)
                trajs.append(traj)
                cur_samples += len(traj["cur_obs"])
                self.agent.encoder.sample_z()
            if task==2:
                traj, reward = self.rollout_action2(accum_context=accum_context)
                trajs.append(traj)
                cur_samples += len(traj["cur_obs"])
                self.agent.encoder.sample_z()
            if task==3:
                traj, reward = self.rollout_action3(accum_context=accum_context)
                trajs.append(traj)
                cur_samples += len(traj["cur_obs"])
                self.agent.encoder.sample_z()
            if task==4:
                traj, reward = self.rollout_action4(accum_context=accum_context)
                trajs.append(traj)
                cur_samples += len(traj["cur_obs"])
                self.agent.encoder.sample_z()
            if task==5:
                traj, reward = self.rollout_action5(accum_context=accum_context)
                trajs.append(traj)
                cur_samples += len(traj["cur_obs"])
                self.agent.encoder.sample_z()
            if update_posterior:
                break
        return trajs, cur_samples, reward



    def obtain_train_samples(
        self,
        max_samples: int,
        update_posterior: bool,
        accum_context: bool = True,
    ) -> Tuple[List[Dict[str, np.ndarray]], int]:
        
        trajs = []
        cur_samples = 0
        reward=0
        while cur_samples < max_samples:
            traj,reward = self.rollout_train(accum_context=accum_context)
            trajs.append(traj)
            cur_samples += len(traj["cur_obs"])
            self.agent.encoder.sample_z()

            if update_posterior:
                break
        return trajs, cur_samples,reward

    def obtain_samples1(
        self,
        max_samples: int,
        update_posterior: bool,
        accum_context: bool = True,
    ) -> Tuple[List[Dict[str, np.ndarray]], int]:
        
        trajs = []
        cur_samples = 0
        reward=0
        while cur_samples < max_samples:
            traj,reward = self.rollout_test1(accum_context=accum_context)
            trajs.append(traj)
            cur_samples += len(traj["cur_obs"])
            self.agent.encoder.sample_z()

            if update_posterior:
                break
        return trajs, cur_samples,reward


    def obtain_samples2(
        self,
        max_samples: int,
        update_posterior: bool,
        accum_context: bool = True,
    ) -> Tuple[List[Dict[str, np.ndarray]], int]:
        
        trajs = []
        cur_samples = 0

        while cur_samples < max_samples:
            traj,reward = self.rollout_test2(accum_context=accum_context)
            trajs.append(traj)
            cur_samples += len(traj["cur_obs"])
            self.agent.encoder.sample_z()

            if update_posterior:
                break
        return trajs, cur_samples,reward

    def obtain_samples3(
        self,
        max_samples: int,
        update_posterior: bool,
        accum_context: bool = True,
    ) -> Tuple[List[Dict[str, np.ndarray]], int]:
        
        trajs = []
        cur_samples = 0

        while cur_samples < max_samples:
            traj,reward = self.rollout_test3(accum_context=accum_context)
            trajs.append(traj)
            cur_samples += len(traj["cur_obs"])
            self.agent.encoder.sample_z()

            if update_posterior:
                break
        return trajs, cur_samples,reward

    def obtain_samples4(
        self,
        max_samples: int,
        update_posterior: bool,
        accum_context: bool = True,
    ) -> Tuple[List[Dict[str, np.ndarray]], int]:
        
        trajs = []
        cur_samples = 0

        while cur_samples < max_samples:
            traj,reward = self.rollout_test4(accum_context=accum_context)
            trajs.append(traj)
            cur_samples += len(traj["cur_obs"])
            self.agent.encoder.sample_z()

            if update_posterior:
                break
        return trajs, cur_samples,reward

    def obtain_samples5(
            self,
            max_samples: int,
            update_posterior: bool,
            accum_context: bool = True,
    ) -> Tuple[List[Dict[str, np.ndarray]], int]:
        
        trajs = []
        cur_samples = 0

        while cur_samples < max_samples:
            traj, reward = self.rollout_test5(accum_context=accum_context)
            trajs.append(traj)
            cur_samples += len(traj["cur_obs"])
            self.agent.encoder.sample_z()

            if update_posterior:
                break
        return trajs, cur_samples, reward

    def rollout_train(self, accum_context: bool = True) -> Dict[str, np.ndarray]:
        
        _cur_obs = []
        _actions = []
        _rewards = []
        _next_obs = []
        _dones = []
        _infos = []

        obs = self.env.reset()
        done = False
        cur_step = 0
        rewards = 0
        while not done:
            action = self.agent.get_action(obs)
            next_obs, reward, done = self.env.step(action)

            
            if accum_context:
                self.update_context(obs=obs, action=action, reward=np.array([reward]))

            _cur_obs.append(obs)
            _actions.append(action)
            _rewards.append(reward)
            _next_obs.append(next_obs)
            _dones.append(done)
            rewards += reward
            

            cur_step += 1
            obs = next_obs

        return dict(
            cur_obs=np.array(_cur_obs),
            actions=np.array(_actions),
            rewards=np.array(_rewards).reshape(-1, 1),
            next_obs=np.array(_next_obs),
            dones=np.array(_dones).reshape(-1, 1),
            
        ), rewards

    def rollout_test1(self, accum_context: bool = True) -> Dict[str, np.ndarray]:
        
        _cur_obs = []
        _actions = []
        _rewards = []
        _next_obs = []
        _dones = []
        _infos = []

        obs = self.env.reset()
        done = False
        cur_step = 0
        rewards = 0
        while not done:
            action = self.agent.get_action(obs)
            next_obs, reward, done = self.env1.step(action)

            
            if accum_context:
                self.update_context(obs=obs, action=action, reward=np.array([reward]))

            _cur_obs.append(obs)
            _actions.append(action)
            _rewards.append(reward)
            _next_obs.append(next_obs)
            _dones.append(done)
            rewards += reward
            

            cur_step += 1
            obs = next_obs

        return dict(
            cur_obs=np.array(_cur_obs),
            actions=np.array(_actions),
            rewards=np.array(_rewards).reshape(-1, 1),
            next_obs=np.array(_next_obs),
            dones=np.array(_dones).reshape(-1, 1),
            
        ),rewards


    def rollout_test2(self, accum_context: bool = True) -> Dict[str, np.ndarray]:
        
        _cur_obs = []
        _actions = []
        _rewards = []
        _next_obs = []
        _dones = []
        _infos = []

        obs = self.env.reset()
        done = False
        cur_step = 0
        rewards = 0
        while not done:
            action = self.agent.get_action(obs)
            next_obs, reward, done = self.env2.step(action)

            
            if accum_context:
                self.update_context(obs=obs, action=action, reward=np.array([reward]))

            _cur_obs.append(obs)
            _actions.append(action)
            _rewards.append(reward)
            _next_obs.append(next_obs)
            _dones.append(done)
            rewards += reward
            

            cur_step += 1
            obs = next_obs

        return dict(
            cur_obs=np.array(_cur_obs),
            actions=np.array(_actions),
            rewards=np.array(_rewards).reshape(-1, 1),
            next_obs=np.array(_next_obs),
            dones=np.array(_dones).reshape(-1, 1),
            
        ), rewards

    def rollout_test3(self, accum_context: bool = True) -> Dict[str, np.ndarray]:
        
        _cur_obs = []
        _actions = []
        _rewards = []
        _next_obs = []
        _dones = []
        _infos = []

        obs = self.env.reset()
        done = False
        cur_step = 0
        rewards = 0
        while not done:
            action = self.agent.get_action(obs)
            next_obs, reward, done = self.env3.step(action)

            
            if accum_context:
                self.update_context(obs=obs, action=action, reward=np.array([reward]))

            _cur_obs.append(obs)
            _actions.append(action)
            _rewards.append(reward)
            _next_obs.append(next_obs)
            _dones.append(done)
            rewards += reward
            

            cur_step += 1
            obs = next_obs

        return dict(
            cur_obs=np.array(_cur_obs),
            actions=np.array(_actions),
            rewards=np.array(_rewards).reshape(-1, 1),
            next_obs=np.array(_next_obs),
            dones=np.array(_dones).reshape(-1, 1),
            
        ), rewards

    def rollout_test4(self, accum_context: bool = True) -> Dict[str, np.ndarray]:
        
        _cur_obs = []
        _actions = []
        _rewards = []
        _next_obs = []
        _dones = []
        _infos = []

        obs = self.env.reset()
        done = False
        cur_step = 0
        rewards = 0
        while not done:
            action = self.agent.get_action(obs)
            next_obs, reward, done = self.env4.step(action)

            
            if accum_context:
                self.update_context(obs=obs, action=action, reward=np.array([reward]))

            _cur_obs.append(obs)
            _actions.append(action)
            _rewards.append(reward)
            _next_obs.append(next_obs)
            _dones.append(done)
            rewards += reward
            

            cur_step += 1
            obs = next_obs

        return dict(
            cur_obs=np.array(_cur_obs),
            actions=np.array(_actions),
            rewards=np.array(_rewards).reshape(-1, 1),
            next_obs=np.array(_next_obs),
            dones=np.array(_dones).reshape(-1, 1),
            
        ), rewards

    def rollout_test5(self, accum_context: bool = True) -> Dict[str, np.ndarray]:
        
        _cur_obs = []
        _actions = []
        _rewards = []
        _next_obs = []
        _dones = []
        _infos = []

        obs = self.env.reset()
        done = False
        cur_step = 0
        rewards = 0
        while not done:
            action = self.agent.get_action(obs)
            next_obs, reward, done = self.env5.step(action)

            
            if accum_context:
                self.update_context(obs=obs, action=action, reward=np.array([reward]))

            _cur_obs.append(obs)
            _actions.append(action)
            _rewards.append(reward)
            _next_obs.append(next_obs)
            _dones.append(done)
            rewards += reward
            

            cur_step += 1
            obs = next_obs

        return dict(
            cur_obs=np.array(_cur_obs),
            actions=np.array(_actions),
            rewards=np.array(_rewards).reshape(-1, 1),
            next_obs=np.array(_next_obs),
            dones=np.array(_dones).reshape(-1, 1),
            
        ), rewards

    
    def rollout_action1(self, accum_context: bool = True) -> Dict[str, np.ndarray]:
        
        _cur_obs = []
        _actions = []
        _rewards = []
        _next_obs = []
        _dones = []
        _infos = []
        a=[]
        b=[]
        mulist1 = []
        mulist2 = []
        mulist3 = []
        obs = self.env.reset()
        done = False
        cur_step = 0
        
        while not done :
            action = self.agent.get_action(obs)
            
            mulist1.append(action[0])
            mulist2.append(action[1])
            mulist3.append(action[2])
            next_obs, reward, done= self.env1.step(action)
            
            if accum_context:
                self.update_context(obs=obs, action=action, reward=np.array([reward]))
            _cur_obs.append(obs)
            _actions.append(action)
            _rewards.append(reward)
            _next_obs.append(next_obs)
            _dones.append(done)
            rewards+=reward
            
            obs = next_obs
        print(mulist1)
        print(mulist2)
        print(mulist3)
        print(rewards)
        return dict(
            cur_obs=np.array(_cur_obs),
            actions=np.array(_actions),
            rewards=np.array(_rewards).reshape(-1, 1),
            next_obs=np.array(_next_obs),
            dones=np.array(_dones).reshape(-1, 1),
            
        ),rewards

    def rollout_action2(self, accum_context: bool = True) -> Dict[str, np.ndarray]:
        
        _cur_obs = []
        _actions = []
        _rewards = []
        _next_obs = []
        _dones = []
        _infos = []
        a = []
        b = []
        mulist1 = []
        mulist2 = []
        mulist3 = []
        obs = self.env.reset()
        done = False
        cur_step = 0
        
        while not done:
            action = self.agent.get_action(obs)
            
            mulist1.append(action[0])
            mulist2.append(action[1])
            mulist3.append(action[2])
            next_obs, reward, done = self.env2.step(action)
            
            if accum_context:
                self.update_context(obs=obs, action=action, reward=np.array([reward]))
            _cur_obs.append(obs)
            _actions.append(action)
            _rewards.append(reward)
            _next_obs.append(next_obs)
            _dones.append(done)
            rewards += reward
            
            obs = next_obs
        print(mulist1)
        print(mulist2)
        print(mulist3)
        print(rewards)
        return dict(
            cur_obs=np.array(_cur_obs),
            actions=np.array(_actions),
            rewards=np.array(_rewards).reshape(-1, 1),
            next_obs=np.array(_next_obs),
            dones=np.array(_dones).reshape(-1, 1),
            
        ), rewards

    def rollout_action3(self, accum_context: bool = True) -> Dict[str, np.ndarray]:
        
        _cur_obs = []
        _actions = []
        _rewards = []
        _next_obs = []
        _dones = []
        _infos = []
        a = []
        b = []
        mulist1 = []
        mulist2 = []
        mulist3 = []
        obs = self.env.reset()
        done = False
        cur_step = 0
        
        while not done:
            action = self.agent.get_action(obs)
            
            mulist1.append(action[0])
            mulist2.append(action[1])
            mulist3.append(action[2])
            next_obs, reward, done = self.env3.step(action)
            
            if accum_context:
                self.update_context(obs=obs, action=action, reward=np.array([reward]))
            _cur_obs.append(obs)
            _actions.append(action)
            _rewards.append(reward)
            _next_obs.append(next_obs)
            _dones.append(done)
            rewards += reward
            
            obs = next_obs
        print(mulist1)
        print(mulist2)
        print(mulist3)
        print(rewards)
        return dict(
            cur_obs=np.array(_cur_obs),
            actions=np.array(_actions),
            rewards=np.array(_rewards).reshape(-1, 1),
            next_obs=np.array(_next_obs),
            dones=np.array(_dones).reshape(-1, 1),
            
        ), rewards

    def rollout_action4(self, accum_context: bool = True) -> Dict[str, np.ndarray]:
        
        _cur_obs = []
        _actions = []
        _rewards = []
        _next_obs = []
        _dones = []
        _infos = []
        a = []
        b = []
        mulist1 = []
        mulist2 = []
        mulist3 = []
        obs = self.env.reset()
        done = False
        cur_step = 0
        
        while not done:
            action = self.agent.get_action(obs)
            
            mulist1.append(action[0])
            mulist2.append(action[1])
            mulist3.append(action[2])
            next_obs, reward, done = self.env4.step(action)
            
            if accum_context:
                self.update_context(obs=obs, action=action, reward=np.array([reward]))
            _cur_obs.append(obs)
            _actions.append(action)
            _rewards.append(reward)
            _next_obs.append(next_obs)
            _dones.append(done)
            rewards += reward
            
            obs = next_obs
        print(mulist1)
        print(mulist2)
        print(mulist3)
        print(rewards)
        return dict(
            cur_obs=np.array(_cur_obs),
            actions=np.array(_actions),
            rewards=np.array(_rewards).reshape(-1, 1),
            next_obs=np.array(_next_obs),
            dones=np.array(_dones).reshape(-1, 1),
            
        ), rewards

    def rollout_action5(self, accum_context: bool = True) -> Dict[str, np.ndarray]:
        
        _cur_obs = []
        _actions = []
        _rewards = []
        _next_obs = []
        _dones = []
        _infos = []
        a = []
        b = []
        mulist1 = []
        mulist2 = []
        mulist3 = []
        obs = self.env.reset()
        done = False
        cur_step = 0
        
        while not done:
            action = self.agent.get_action(obs)
            
            mulist1.append(action[0])
            mulist2.append(action[1])
            mulist3.append(action[2])
            next_obs, reward, done = self.env5.step(action)
            
            if accum_context:
                self.update_context(obs=obs, action=action, reward=np.array([reward]))
            _cur_obs.append(obs)
            _actions.append(action)
            _rewards.append(reward)
            _next_obs.append(next_obs)
            _dones.append(done)
            rewards += reward
            
            obs = next_obs
        print(mulist1)
        print(mulist2)
        print(mulist3)
        print(rewards)
        return dict(
            cur_obs=np.array(_cur_obs),
            actions=np.array(_actions),
            rewards=np.array(_rewards).reshape(-1, 1),
            next_obs=np.array(_next_obs),
            dones=np.array(_dones).reshape(-1, 1),
            
        ), rewards

    def update_context(self, obs: np.ndarray, action: np.ndarray, reward: np.ndarray) -> None:
        
        obs = np.array(obs)
        action = np.array(action)
        reward = np.array(reward)

        obs = torch.from_numpy(obs).float().to(self.device)
        action = torch.from_numpy(action).float().to(self.device)
        reward = torch.from_numpy(reward).float().to(self.device)
        transition = torch.cat([obs, action, reward], dim=-1).to(self.device)

        if self.agent.encoder.context is None:
            self.agent.encoder.context = transition
        else:
            self.agent.encoder.context = torch.cat([self.agent.encoder.context, transition], dim=-1).to(
                self.device,
            )
