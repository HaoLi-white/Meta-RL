
"""
2023-03-23:完成SIR_DQN环境编写
"""
from parameter import *
import math
from gym.utils import seeding
from typing import Any, Dict, List, Tuple

class SIR:
    def __init__(self):
        self.state_dim = 10  # 状态空间
        self.action_dim = 3  # 动作空间

    # 状态量复位
    def reset(self):
        return self.origin_state

    def get_all_task_idx(self) -> List[int]:
        return list(range(len(self.tasks)))

    def reset_task(self, idx: int) -> None:

        return reward


    # 单步状态更新
    def step1(self, action_idx):
        next_state = self.origin_state  # 初始化
        reward = 0
        done = False
        b0 = action_idx[0][0]  # 连续
        b1 = action_idx[0][1]  # 连续
        b2 = action_idx[0][2]  # 连续
        t = self.t  # 为了方便书写,不用self.t作索引变量，采用再赋值一个t的方法


        return next_state, reward, done

    def step2(self, action_idx):
        next_state = self.origin_state  # 初始化
        reward = 0
        done = False


        return next_state, reward, done