import os
from typing import Any, Dict, List

import numpy as np
import torch
import yaml
from gym.envs.mujoco.half_cheetah import HalfCheetahEnv


from env import *
from algorithm.meta_learner import MetaLearner
from algorithm.sac import SAC
from algorithm.env1 import *
from algorithm.env2 import *
from algorithm.env3 import *
from algorithm.env4 import *
from algorithm.env5 import *

if __name__ == "__main__":

    env=SIR()
    env1 = SIR1()
    env2 = SIR2()
    env3 = SIR3()
    env4 = SIR4()
    env5 = SIR5()
    tasks: List[int] = env.get_all_task_idx()

    
    args = {
        "env_name": "IoV-SEIRQ",
        "seed":1,
        "latent_dim": 5,
        "train_tasks": 5,
        "test_tasks": 5,
        "sac_params":
            {
            "gamma": 0.99,

            "kl_lambda": 0.1,

            "batch_size": 256,

            "qf_lr": 0.0003,

            "encoder_lr": 0.0001,

            "policy_lr": 0.002,
            },
        "PEARL_params":
            {

            "num_iterations": 50,

            "num_sample_tasks": 3,

            "num_init_samples": 2000,

            "num_prior_samples": 2000,

            "num_posterior_samples": 2000,

            "num_meta_grads": 50,

            "meta_batch_size": 4,

            "batch_size": 256,

            "max_step": 200,

            "max_buffer_size": 1000000,

            "num_stop_conditions": 3,

            "stop_goal": 1900
            }
    }


    np.random.seed(args["seed"])
    torch.manual_seed(args["seed"])

    observ_dim: int = env.state_dim
    action_dim: int = env.action_dim
    hidden_dim: int = 128

    device: torch.device = (
        torch.device("cuda", index=experiment_config["gpu_index"])
        if torch.cuda.is_available()
        else torch.device("cpu")
    )

    agent = SAC(
        observ_dim=observ_dim,
        action_dim=action_dim,
        latent_dim=args["latent_dim"],
        hidden_dim=hidden_dim,
        encoder_input_dim=observ_dim + action_dim + 1,
        encoder_output_dim=args["latent_dim"] * 2,
        device=device,
        **args["sac_params"],
    )

    meta_learner = MetaLearner(
        env=env,
        env1=env1,
        env2=env2,
        env3=env3,
        env4=env4,
        env5=env5,
        env_name=args["env_name"],
        agent=agent,
        observ_dim=observ_dim,
        action_dim=action_dim,
        train_tasks=tasks[: args["train_tasks"]],
        test_tasks=tasks[-args["test_tasks"] :],
        save_exp_name="exp_1",
        save_file_name="null",
        load_exp_name="null",
        load_file_name="null",
        load_ckpt_num=0,
        device=device,
        **args["PEARL_params"],
    )

    
    meta_learner.meta_train()
